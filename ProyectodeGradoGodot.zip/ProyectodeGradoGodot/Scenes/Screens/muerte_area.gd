extends Area2D
@export var destino: Vector2 = Vector2(94.0, 82.0)  
var util = preload("res://Scenes/Screens/player_info.gd")


func _on_body_entered(body: Node2D) -> void:
	print("Entró:", body.name, "de tipo", body.get_class())
	if body.name == "ninja_frog":
		print("¡Confirmado! Es el jugador.")
		body.global_position = destino
		
