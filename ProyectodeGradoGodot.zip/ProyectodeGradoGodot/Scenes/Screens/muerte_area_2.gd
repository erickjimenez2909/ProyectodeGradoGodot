extends Area2D

@export var destino: Vector2 = Vector2(5108.0, 371.0)  

func _on_body_entered(body: Node2D) -> void:
	print("Entró:", body.name, "de tipo", body.get_class())
	if body.name == "ninja_frog":
		print("¡Confirmado! Es el jugador.")
		body.global_position = destino
		
